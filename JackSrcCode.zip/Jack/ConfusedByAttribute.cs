﻿using System;

// Token: 0x02000149 RID: 329
internal class ConfusedByAttribute : Attribute
{
	// Token: 0x06001E33 RID: 7731 RVA: 0x00735A64 File Offset: 0x00733C64
	public ConfusedByAttribute(string string_0)
	{
	}
}
