﻿using System;

// Token: 0x02000148 RID: 328
internal class Jack_ProcessedByFody
{
	// Token: 0x04000FDD RID: 4061
	internal const string FodyVersion = "6.6.4.0";

	// Token: 0x04000FDE RID: 4062
	internal const string Costura = "5.7.0";
}
