﻿using System;

namespace Jack.Core
{
	// Token: 0x0200012C RID: 300
	internal class Descriptors
	{
		// Token: 0x17000335 RID: 821
		// (get) Token: 0x060019B3 RID: 6579 RVA: 0x0072A7F8 File Offset: 0x007289F8
		// (set) Token: 0x060019B4 RID: 6580 RVA: 0x0072A80C File Offset: 0x00728A0C
		public static int Main_DescriptorFields { get; set; }

		// Token: 0x17000336 RID: 822
		// (get) Token: 0x060019B5 RID: 6581 RVA: 0x0072A820 File Offset: 0x00728A20
		// (set) Token: 0x060019B6 RID: 6582 RVA: 0x0072A834 File Offset: 0x00728A34
		public static int ObjectManager_First { get; set; }

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x060019B7 RID: 6583 RVA: 0x0072A848 File Offset: 0x00728A48
		// (set) Token: 0x060019B8 RID: 6584 RVA: 0x0072A85C File Offset: 0x00728A5C
		public static int ObjectManager_Next { get; set; }

		// Token: 0x17000338 RID: 824
		// (get) Token: 0x060019B9 RID: 6585 RVA: 0x0072A870 File Offset: 0x00728A70
		// (set) Token: 0x060019BA RID: 6586 RVA: 0x0072A884 File Offset: 0x00728A84
		public static int UnitFields_Information_1 { get; set; }

		// Token: 0x17000339 RID: 825
		// (get) Token: 0x060019BB RID: 6587 RVA: 0x0072A898 File Offset: 0x00728A98
		// (set) Token: 0x060019BC RID: 6588 RVA: 0x0072A8AC File Offset: 0x00728AAC
		public static int UnitFields_X { get; set; }

		// Token: 0x1700033A RID: 826
		// (get) Token: 0x060019BD RID: 6589 RVA: 0x0072A8C0 File Offset: 0x00728AC0
		// (set) Token: 0x060019BE RID: 6590 RVA: 0x0072A8D4 File Offset: 0x00728AD4
		public static int UnitFields_Y { get; set; }

		// Token: 0x1700033B RID: 827
		// (get) Token: 0x060019BF RID: 6591 RVA: 0x0072A8E8 File Offset: 0x00728AE8
		// (set) Token: 0x060019C0 RID: 6592 RVA: 0x0072A8FC File Offset: 0x00728AFC
		public static int UnitFields_Z { get; set; }

		// Token: 0x1700033C RID: 828
		// (get) Token: 0x060019C1 RID: 6593 RVA: 0x0072A910 File Offset: 0x00728B10
		// (set) Token: 0x060019C2 RID: 6594 RVA: 0x0072A924 File Offset: 0x00728B24
		public static int UnitFields_Speed { get; set; }

		// Token: 0x1700033D RID: 829
		// (get) Token: 0x060019C3 RID: 6595 RVA: 0x0072A938 File Offset: 0x00728B38
		// (set) Token: 0x060019C4 RID: 6596 RVA: 0x0072A94C File Offset: 0x00728B4C
		public static int UnitFields_Swimming { get; set; }

		// Token: 0x1700033E RID: 830
		// (get) Token: 0x060019C5 RID: 6597 RVA: 0x0072A960 File Offset: 0x00728B60
		// (set) Token: 0x060019C6 RID: 6598 RVA: 0x0072A974 File Offset: 0x00728B74
		public static int UnitFields_SwimmingMask { get; set; }

		// Token: 0x1700033F RID: 831
		// (get) Token: 0x060019C7 RID: 6599 RVA: 0x0072A988 File Offset: 0x00728B88
		// (set) Token: 0x060019C8 RID: 6600 RVA: 0x0072A99C File Offset: 0x00728B9C
		public static int UnitFields_Flying { get; set; }

		// Token: 0x17000340 RID: 832
		// (get) Token: 0x060019C9 RID: 6601 RVA: 0x0072A9B0 File Offset: 0x00728BB0
		// (set) Token: 0x060019CA RID: 6602 RVA: 0x0072A9C4 File Offset: 0x00728BC4
		public static int UnitFields_FlyingMask { get; set; }

		// Token: 0x17000341 RID: 833
		// (get) Token: 0x060019CB RID: 6603 RVA: 0x0072A9D8 File Offset: 0x00728BD8
		// (set) Token: 0x060019CC RID: 6604 RVA: 0x0072A9EC File Offset: 0x00728BEC
		public static int UnitFields_Information_2 { get; set; }

		// Token: 0x17000342 RID: 834
		// (get) Token: 0x060019CD RID: 6605 RVA: 0x0072AA00 File Offset: 0x00728C00
		// (set) Token: 0x060019CE RID: 6606 RVA: 0x0072AA14 File Offset: 0x00728C14
		public static int UnitFields_Name { get; set; }

		// Token: 0x17000343 RID: 835
		// (get) Token: 0x060019CF RID: 6607 RVA: 0x0072AA28 File Offset: 0x00728C28
		// (set) Token: 0x060019D0 RID: 6608 RVA: 0x0072AA3C File Offset: 0x00728C3C
		public static int UnitFields_CreatureRank { get; set; }

		// Token: 0x17000344 RID: 836
		// (get) Token: 0x060019D1 RID: 6609 RVA: 0x0072AA50 File Offset: 0x00728C50
		// (set) Token: 0x060019D2 RID: 6610 RVA: 0x0072AA64 File Offset: 0x00728C64
		public static int UnitFields_CreatureType { get; set; }

		// Token: 0x17000345 RID: 837
		// (get) Token: 0x060019D3 RID: 6611 RVA: 0x0072AA78 File Offset: 0x00728C78
		// (set) Token: 0x060019D4 RID: 6612 RVA: 0x0072AA8C File Offset: 0x00728C8C
		public static int UnitFields_GUID { get; set; }

		// Token: 0x17000346 RID: 838
		// (get) Token: 0x060019D5 RID: 6613 RVA: 0x0072AAA0 File Offset: 0x00728CA0
		// (set) Token: 0x060019D6 RID: 6614 RVA: 0x0072AAB4 File Offset: 0x00728CB4
		public static int UnitFields_Level { get; set; }

		// Token: 0x17000347 RID: 839
		// (get) Token: 0x060019D7 RID: 6615 RVA: 0x0072AAC8 File Offset: 0x00728CC8
		// (set) Token: 0x060019D8 RID: 6616 RVA: 0x0072AADC File Offset: 0x00728CDC
		public static int UnitFields_CurrentHealth { get; set; }

		// Token: 0x17000348 RID: 840
		// (get) Token: 0x060019D9 RID: 6617 RVA: 0x0072AAF0 File Offset: 0x00728CF0
		// (set) Token: 0x060019DA RID: 6618 RVA: 0x0072AB04 File Offset: 0x00728D04
		public static int UnitFields_MaxHealth { get; set; }

		// Token: 0x17000349 RID: 841
		// (get) Token: 0x060019DB RID: 6619 RVA: 0x0072AB18 File Offset: 0x00728D18
		// (set) Token: 0x060019DC RID: 6620 RVA: 0x0072AB2C File Offset: 0x00728D2C
		public static int UnitFields_CurrentPower { get; set; }

		// Token: 0x1700034A RID: 842
		// (get) Token: 0x060019DD RID: 6621 RVA: 0x0072AB40 File Offset: 0x00728D40
		// (set) Token: 0x060019DE RID: 6622 RVA: 0x0072AB54 File Offset: 0x00728D54
		public static int UnitFields_MaxPower { get; set; }

		// Token: 0x1700034B RID: 843
		// (get) Token: 0x060019DF RID: 6623 RVA: 0x0072AB68 File Offset: 0x00728D68
		// (set) Token: 0x060019E0 RID: 6624 RVA: 0x0072AB7C File Offset: 0x00728D7C
		public static int UnitFields_ComboPoints { get; set; }

		// Token: 0x1700034C RID: 844
		// (get) Token: 0x060019E1 RID: 6625 RVA: 0x0072AB90 File Offset: 0x00728D90
		// (set) Token: 0x060019E2 RID: 6626 RVA: 0x0072ABA4 File Offset: 0x00728DA4
		public static int UnitFields_ComboPointsDruid { get; set; }

		// Token: 0x1700034D RID: 845
		// (get) Token: 0x060019E3 RID: 6627 RVA: 0x0072ABB8 File Offset: 0x00728DB8
		// (set) Token: 0x060019E4 RID: 6628 RVA: 0x0072ABCC File Offset: 0x00728DCC
		public static int UnitFields_TargetGUID { get; set; }

		// Token: 0x1700034E RID: 846
		// (get) Token: 0x060019E5 RID: 6629 RVA: 0x0072ABE0 File Offset: 0x00728DE0
		// (set) Token: 0x060019E6 RID: 6630 RVA: 0x0072ABF4 File Offset: 0x00728DF4
		public static int UnitFields_Facing { get; set; }

		// Token: 0x1700034F RID: 847
		// (get) Token: 0x060019E7 RID: 6631 RVA: 0x0072AC08 File Offset: 0x00728E08
		// (set) Token: 0x060019E8 RID: 6632 RVA: 0x0072AC1C File Offset: 0x00728E1C
		public static int UnitFields_Pitch { get; set; }

		// Token: 0x17000350 RID: 848
		// (get) Token: 0x060019E9 RID: 6633 RVA: 0x0072AC30 File Offset: 0x00728E30
		// (set) Token: 0x060019EA RID: 6634 RVA: 0x0072AC44 File Offset: 0x00728E44
		public static int UnitFields_Flags1 { get; set; }

		// Token: 0x17000351 RID: 849
		// (get) Token: 0x060019EB RID: 6635 RVA: 0x0072AC58 File Offset: 0x00728E58
		// (set) Token: 0x060019EC RID: 6636 RVA: 0x0072AC6C File Offset: 0x00728E6C
		public static int UnitFields_DynamicFlags { get; set; }

		// Token: 0x17000352 RID: 850
		// (get) Token: 0x060019ED RID: 6637 RVA: 0x0072AC80 File Offset: 0x00728E80
		// (set) Token: 0x060019EE RID: 6638 RVA: 0x0072AC94 File Offset: 0x00728E94
		public static int UnitFields_IsCasting { get; set; }

		// Token: 0x17000353 RID: 851
		// (get) Token: 0x060019EF RID: 6639 RVA: 0x0072ACA8 File Offset: 0x00728EA8
		// (set) Token: 0x060019F0 RID: 6640 RVA: 0x0072ACBC File Offset: 0x00728EBC
		public static int UnitFields_IsChanneling { get; set; }

		// Token: 0x17000354 RID: 852
		// (get) Token: 0x060019F1 RID: 6641 RVA: 0x0072ACD0 File Offset: 0x00728ED0
		// (set) Token: 0x060019F2 RID: 6642 RVA: 0x0072ACE4 File Offset: 0x00728EE4
		public static int UnitFields_Race { get; set; }

		// Token: 0x17000355 RID: 853
		// (get) Token: 0x060019F3 RID: 6643 RVA: 0x0072ACF8 File Offset: 0x00728EF8
		// (set) Token: 0x060019F4 RID: 6644 RVA: 0x0072AD0C File Offset: 0x00728F0C
		public static int UnitFields_Class { get; set; }

		// Token: 0x17000356 RID: 854
		// (get) Token: 0x060019F5 RID: 6645 RVA: 0x0072AD20 File Offset: 0x00728F20
		// (set) Token: 0x060019F6 RID: 6646 RVA: 0x0072AD34 File Offset: 0x00728F34
		public static int UnitFields_DisplayID { get; set; }

		// Token: 0x17000357 RID: 855
		// (get) Token: 0x060019F7 RID: 6647 RVA: 0x0072AD48 File Offset: 0x00728F48
		// (set) Token: 0x060019F8 RID: 6648 RVA: 0x0072AD5C File Offset: 0x00728F5C
		public static int UnitFields_MountDisplayID { get; set; }

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x060019F9 RID: 6649 RVA: 0x0072AD70 File Offset: 0x00728F70
		// (set) Token: 0x060019FA RID: 6650 RVA: 0x0072AD84 File Offset: 0x00728F84
		public static int UnitFields_Size { get; set; }

		// Token: 0x17000359 RID: 857
		// (get) Token: 0x060019FB RID: 6651 RVA: 0x0072AD98 File Offset: 0x00728F98
		// (set) Token: 0x060019FC RID: 6652 RVA: 0x0072ADAC File Offset: 0x00728FAC
		public static int UnitFields_Matrix { get; set; }

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x060019FD RID: 6653 RVA: 0x0072ADC0 File Offset: 0x00728FC0
		// (set) Token: 0x060019FE RID: 6654 RVA: 0x0072ADD4 File Offset: 0x00728FD4
		public static int PlayerFields_NameCount { get; set; }

		// Token: 0x1700035B RID: 859
		// (get) Token: 0x060019FF RID: 6655 RVA: 0x0072ADE8 File Offset: 0x00728FE8
		// (set) Token: 0x06001A00 RID: 6656 RVA: 0x0072ADFC File Offset: 0x00728FFC
		public static int PlayerFields_NameArray { get; set; }

		// Token: 0x1700035C RID: 860
		// (get) Token: 0x06001A01 RID: 6657 RVA: 0x0072AE10 File Offset: 0x00729010
		// (set) Token: 0x06001A02 RID: 6658 RVA: 0x0072AE24 File Offset: 0x00729024
		public static int PlayerFields_NameEntryAndGUID { get; set; }

		// Token: 0x1700035D RID: 861
		// (get) Token: 0x06001A03 RID: 6659 RVA: 0x0072AE38 File Offset: 0x00729038
		// (set) Token: 0x06001A04 RID: 6660 RVA: 0x0072AE4C File Offset: 0x0072904C
		public static int ObjectFields_X { get; set; }

		// Token: 0x1700035E RID: 862
		// (get) Token: 0x06001A05 RID: 6661 RVA: 0x0072AE60 File Offset: 0x00729060
		// (set) Token: 0x06001A06 RID: 6662 RVA: 0x0072AE74 File Offset: 0x00729074
		public static int ObjectFields_Y { get; set; }

		// Token: 0x1700035F RID: 863
		// (get) Token: 0x06001A07 RID: 6663 RVA: 0x0072AE88 File Offset: 0x00729088
		// (set) Token: 0x06001A08 RID: 6664 RVA: 0x0072AE9C File Offset: 0x0072909C
		public static int ObjectFields_Z { get; set; }

		// Token: 0x17000360 RID: 864
		// (get) Token: 0x06001A09 RID: 6665 RVA: 0x0072AEB0 File Offset: 0x007290B0
		// (set) Token: 0x06001A0A RID: 6666 RVA: 0x0072AEC4 File Offset: 0x007290C4
		public static int ObjectFields_Type { get; set; }

		// Token: 0x17000361 RID: 865
		// (get) Token: 0x06001A0B RID: 6667 RVA: 0x0072AED8 File Offset: 0x007290D8
		// (set) Token: 0x06001A0C RID: 6668 RVA: 0x0072AEEC File Offset: 0x007290EC
		public static int ObjectFields_Detail { get; set; }

		// Token: 0x17000362 RID: 866
		// (get) Token: 0x06001A0D RID: 6669 RVA: 0x0072AF00 File Offset: 0x00729100
		// (set) Token: 0x06001A0E RID: 6670 RVA: 0x0072AF14 File Offset: 0x00729114
		public static int ObjectFields_Name1 { get; set; }

		// Token: 0x17000363 RID: 867
		// (get) Token: 0x06001A0F RID: 6671 RVA: 0x0072AF28 File Offset: 0x00729128
		// (set) Token: 0x06001A10 RID: 6672 RVA: 0x0072AF3C File Offset: 0x0072913C
		public static int ObjectFields_Name2 { get; set; }

		// Token: 0x17000364 RID: 868
		// (get) Token: 0x06001A11 RID: 6673 RVA: 0x0072AF50 File Offset: 0x00729150
		// (set) Token: 0x06001A12 RID: 6674 RVA: 0x0072AF64 File Offset: 0x00729164
		public static int ObjectFields_CreatorGUID { get; set; }

		// Token: 0x17000365 RID: 869
		// (get) Token: 0x06001A13 RID: 6675 RVA: 0x0072AF78 File Offset: 0x00729178
		// (set) Token: 0x06001A14 RID: 6676 RVA: 0x0072AF8C File Offset: 0x0072918C
		public static int ObjectFields_DisplayID { get; set; }

		// Token: 0x17000366 RID: 870
		// (get) Token: 0x06001A15 RID: 6677 RVA: 0x0072AFA0 File Offset: 0x007291A0
		// (set) Token: 0x06001A16 RID: 6678 RVA: 0x0072AFB4 File Offset: 0x007291B4
		public static int ObjectFields_ItemID { get; set; }

		// Token: 0x17000367 RID: 871
		// (get) Token: 0x06001A17 RID: 6679 RVA: 0x0072AFC8 File Offset: 0x007291C8
		// (set) Token: 0x06001A18 RID: 6680 RVA: 0x0072AFDC File Offset: 0x007291DC
		public static int ObjectFields_Flags { get; set; }

		// Token: 0x17000368 RID: 872
		// (get) Token: 0x06001A19 RID: 6681 RVA: 0x0072AFF0 File Offset: 0x007291F0
		// (set) Token: 0x06001A1A RID: 6682 RVA: 0x0072B004 File Offset: 0x00729204
		public static int ObjectFields_LowFlags { get; set; }

		// Token: 0x17000369 RID: 873
		// (get) Token: 0x06001A1B RID: 6683 RVA: 0x0072B018 File Offset: 0x00729218
		// (set) Token: 0x06001A1C RID: 6684 RVA: 0x0072B02C File Offset: 0x0072922C
		public static int ObjectFields_Available { get; set; }

		// Token: 0x1700036A RID: 874
		// (get) Token: 0x06001A1D RID: 6685 RVA: 0x0072B040 File Offset: 0x00729240
		// (set) Token: 0x06001A1E RID: 6686 RVA: 0x0072B054 File Offset: 0x00729254
		public static int ObjectFields_Matrix { get; set; }

		// Token: 0x1700036B RID: 875
		// (get) Token: 0x06001A1F RID: 6687 RVA: 0x0072B068 File Offset: 0x00729268
		// (set) Token: 0x06001A20 RID: 6688 RVA: 0x0072B07C File Offset: 0x0072927C
		public static int AreaTriggerFields_X { get; set; }

		// Token: 0x1700036C RID: 876
		// (get) Token: 0x06001A21 RID: 6689 RVA: 0x0072B090 File Offset: 0x00729290
		// (set) Token: 0x06001A22 RID: 6690 RVA: 0x0072B0A4 File Offset: 0x007292A4
		public static int AreaTriggerFields_Y { get; set; }

		// Token: 0x1700036D RID: 877
		// (get) Token: 0x06001A23 RID: 6691 RVA: 0x0072B0B8 File Offset: 0x007292B8
		// (set) Token: 0x06001A24 RID: 6692 RVA: 0x0072B0CC File Offset: 0x007292CC
		public static int AreaTriggerFields_Z { get; set; }

		// Token: 0x1700036E RID: 878
		// (get) Token: 0x06001A25 RID: 6693 RVA: 0x0072B0E0 File Offset: 0x007292E0
		// (set) Token: 0x06001A26 RID: 6694 RVA: 0x0072B0F4 File Offset: 0x007292F4
		public static int AreaTrigger_CreatorGUID { get; set; }

		// Token: 0x1700036F RID: 879
		// (get) Token: 0x06001A27 RID: 6695 RVA: 0x0072B108 File Offset: 0x00729308
		// (set) Token: 0x06001A28 RID: 6696 RVA: 0x0072B11C File Offset: 0x0072931C
		public static int ActionBar_First { get; set; }

		// Token: 0x17000370 RID: 880
		// (get) Token: 0x06001A29 RID: 6697 RVA: 0x0072B130 File Offset: 0x00729330
		// (set) Token: 0x06001A2A RID: 6698 RVA: 0x0072B144 File Offset: 0x00729344
		public static int Cooldown_First { get; set; }

		// Token: 0x17000371 RID: 881
		// (get) Token: 0x06001A2B RID: 6699 RVA: 0x0072B158 File Offset: 0x00729358
		// (set) Token: 0x06001A2C RID: 6700 RVA: 0x0072B16C File Offset: 0x0072936C
		public static int Cooldown_Next { get; set; }

		// Token: 0x17000372 RID: 882
		// (get) Token: 0x06001A2D RID: 6701 RVA: 0x0072B180 File Offset: 0x00729380
		// (set) Token: 0x06001A2E RID: 6702 RVA: 0x0072B194 File Offset: 0x00729394
		public static int Cooldown_SpellID { get; set; }

		// Token: 0x17000373 RID: 883
		// (get) Token: 0x06001A2F RID: 6703 RVA: 0x0072B1A8 File Offset: 0x007293A8
		// (set) Token: 0x06001A30 RID: 6704 RVA: 0x0072B1BC File Offset: 0x007293BC
		public static int Cooldown_ItemID { get; set; }

		// Token: 0x17000374 RID: 884
		// (get) Token: 0x06001A31 RID: 6705 RVA: 0x0072B1D0 File Offset: 0x007293D0
		// (set) Token: 0x06001A32 RID: 6706 RVA: 0x0072B1E4 File Offset: 0x007293E4
		public static int Cooldown_RecoveryStart { get; set; }

		// Token: 0x17000375 RID: 885
		// (get) Token: 0x06001A33 RID: 6707 RVA: 0x0072B1F8 File Offset: 0x007293F8
		// (set) Token: 0x06001A34 RID: 6708 RVA: 0x0072B20C File Offset: 0x0072940C
		public static int Cooldown_Recovery1 { get; set; }

		// Token: 0x17000376 RID: 886
		// (get) Token: 0x06001A35 RID: 6709 RVA: 0x0072B220 File Offset: 0x00729420
		// (set) Token: 0x06001A36 RID: 6710 RVA: 0x0072B234 File Offset: 0x00729434
		public static int Cooldown_CatRecoveryStart { get; set; }

		// Token: 0x17000377 RID: 887
		// (get) Token: 0x06001A37 RID: 6711 RVA: 0x0072B248 File Offset: 0x00729448
		// (set) Token: 0x06001A38 RID: 6712 RVA: 0x0072B25C File Offset: 0x0072945C
		public static int Cooldown_Recovery2 { get; set; }

		// Token: 0x17000378 RID: 888
		// (get) Token: 0x06001A39 RID: 6713 RVA: 0x0072B270 File Offset: 0x00729470
		// (set) Token: 0x06001A3A RID: 6714 RVA: 0x0072B284 File Offset: 0x00729484
		public static int Cooldown_GCDRecoveryStart { get; set; }

		// Token: 0x17000379 RID: 889
		// (get) Token: 0x06001A3B RID: 6715 RVA: 0x0072B298 File Offset: 0x00729498
		// (set) Token: 0x06001A3C RID: 6716 RVA: 0x0072B2AC File Offset: 0x007294AC
		public static int Auras_Count1 { get; set; }

		// Token: 0x1700037A RID: 890
		// (get) Token: 0x06001A3D RID: 6717 RVA: 0x0072B2C0 File Offset: 0x007294C0
		// (set) Token: 0x06001A3E RID: 6718 RVA: 0x0072B2D4 File Offset: 0x007294D4
		public static int Auras_Count2 { get; set; }

		// Token: 0x1700037B RID: 891
		// (get) Token: 0x06001A3F RID: 6719 RVA: 0x0072B2E8 File Offset: 0x007294E8
		// (set) Token: 0x06001A40 RID: 6720 RVA: 0x0072B2FC File Offset: 0x007294FC
		public static int Auras_Table1 { get; set; }

		// Token: 0x1700037C RID: 892
		// (get) Token: 0x06001A41 RID: 6721 RVA: 0x0072B310 File Offset: 0x00729510
		// (set) Token: 0x06001A42 RID: 6722 RVA: 0x0072B324 File Offset: 0x00729524
		public static int Auras_Table2 { get; set; }

		// Token: 0x1700037D RID: 893
		// (get) Token: 0x06001A43 RID: 6723 RVA: 0x0072B338 File Offset: 0x00729538
		// (set) Token: 0x06001A44 RID: 6724 RVA: 0x0072B34C File Offset: 0x0072954C
		public static int Auras_Size { get; set; }

		// Token: 0x1700037E RID: 894
		// (get) Token: 0x06001A45 RID: 6725 RVA: 0x0072B360 File Offset: 0x00729560
		// (set) Token: 0x06001A46 RID: 6726 RVA: 0x0072B374 File Offset: 0x00729574
		public static int Auras_SpellID { get; set; }

		// Token: 0x1700037F RID: 895
		// (get) Token: 0x06001A47 RID: 6727 RVA: 0x0072B388 File Offset: 0x00729588
		// (set) Token: 0x06001A48 RID: 6728 RVA: 0x0072B39C File Offset: 0x0072959C
		public static int Auras_OwnerGUID { get; set; }

		// Token: 0x17000380 RID: 896
		// (get) Token: 0x06001A49 RID: 6729 RVA: 0x0072B3B0 File Offset: 0x007295B0
		// (set) Token: 0x06001A4A RID: 6730 RVA: 0x0072B3C4 File Offset: 0x007295C4
		public static int Auras_Flags { get; set; }

		// Token: 0x17000381 RID: 897
		// (get) Token: 0x06001A4B RID: 6731 RVA: 0x0072B3D8 File Offset: 0x007295D8
		// (set) Token: 0x06001A4C RID: 6732 RVA: 0x0072B3EC File Offset: 0x007295EC
		public static int ContainerFields_NumSlots { get; set; }

		// Token: 0x17000382 RID: 898
		// (get) Token: 0x06001A4D RID: 6733 RVA: 0x0072B400 File Offset: 0x00729600
		// (set) Token: 0x06001A4E RID: 6734 RVA: 0x0072B414 File Offset: 0x00729614
		public static int ContainerFields_BagSlots { get; set; }

		// Token: 0x17000383 RID: 899
		// (get) Token: 0x06001A4F RID: 6735 RVA: 0x0072B428 File Offset: 0x00729628
		// (set) Token: 0x06001A50 RID: 6736 RVA: 0x0072B43C File Offset: 0x0072963C
		public static int ContainerFields_BagSlotsNext { get; set; }

		// Token: 0x17000384 RID: 900
		// (get) Token: 0x06001A51 RID: 6737 RVA: 0x0072B450 File Offset: 0x00729650
		// (set) Token: 0x06001A52 RID: 6738 RVA: 0x0072B464 File Offset: 0x00729664
		public static int ContainerFields_GUID { get; set; }

		// Token: 0x17000385 RID: 901
		// (get) Token: 0x06001A53 RID: 6739 RVA: 0x0072B478 File Offset: 0x00729678
		// (set) Token: 0x06001A54 RID: 6740 RVA: 0x0072B48C File Offset: 0x0072968C
		public static int ItemFields_OwnerGUID { get; set; }

		// Token: 0x17000386 RID: 902
		// (get) Token: 0x06001A55 RID: 6741 RVA: 0x0072B4A0 File Offset: 0x007296A0
		// (set) Token: 0x06001A56 RID: 6742 RVA: 0x0072B4B4 File Offset: 0x007296B4
		public static int ItemFields_StackCount { get; set; }

		// Token: 0x17000387 RID: 903
		// (get) Token: 0x06001A57 RID: 6743 RVA: 0x0072B4C8 File Offset: 0x007296C8
		// (set) Token: 0x06001A58 RID: 6744 RVA: 0x0072B4DC File Offset: 0x007296DC
		public static int ItemFields_ItemID { get; set; }

		// Token: 0x17000388 RID: 904
		// (get) Token: 0x06001A59 RID: 6745 RVA: 0x0072B4F0 File Offset: 0x007296F0
		// (set) Token: 0x06001A5A RID: 6746 RVA: 0x0072B504 File Offset: 0x00729704
		public static int ItemFields_Durability { get; set; }

		// Token: 0x17000389 RID: 905
		// (get) Token: 0x06001A5B RID: 6747 RVA: 0x0072B518 File Offset: 0x00729718
		// (set) Token: 0x06001A5C RID: 6748 RVA: 0x0072B52C File Offset: 0x0072972C
		public static int ItemFields_MaxDurability { get; set; }

		// Token: 0x1700038A RID: 906
		// (get) Token: 0x06001A5D RID: 6749 RVA: 0x0072B540 File Offset: 0x00729740
		// (set) Token: 0x06001A5E RID: 6750 RVA: 0x0072B554 File Offset: 0x00729754
		public static int ItemFields_ContainedIn { get; set; }

		// Token: 0x1700038B RID: 907
		// (get) Token: 0x06001A5F RID: 6751 RVA: 0x0072B568 File Offset: 0x00729768
		// (set) Token: 0x06001A60 RID: 6752 RVA: 0x0072B57C File Offset: 0x0072977C
		public static int ItemFields_EffectID { get; set; }

		// Token: 0x1700038C RID: 908
		// (get) Token: 0x06001A61 RID: 6753 RVA: 0x0072B590 File Offset: 0x00729790
		// (set) Token: 0x06001A62 RID: 6754 RVA: 0x0072B5A4 File Offset: 0x007297A4
		public static int ItemFields_MainBag { get; set; }

		// Token: 0x1700038D RID: 909
		// (get) Token: 0x06001A63 RID: 6755 RVA: 0x0072B5B8 File Offset: 0x007297B8
		// (set) Token: 0x06001A64 RID: 6756 RVA: 0x0072B5CC File Offset: 0x007297CC
		public static int ItemFields_Bank { get; set; }

		// Token: 0x1700038E RID: 910
		// (get) Token: 0x06001A65 RID: 6757 RVA: 0x0072B5E0 File Offset: 0x007297E0
		// (set) Token: 0x06001A66 RID: 6758 RVA: 0x0072B5F4 File Offset: 0x007297F4
		public static int ItemFields_Equipped { get; set; }

		// Token: 0x1700038F RID: 911
		// (get) Token: 0x06001A67 RID: 6759 RVA: 0x0072B608 File Offset: 0x00729808
		// (set) Token: 0x06001A68 RID: 6760 RVA: 0x0072B61C File Offset: 0x0072981C
		public static int ItemFields_NextSlot { get; set; }

		// Token: 0x17000390 RID: 912
		// (get) Token: 0x06001A69 RID: 6761 RVA: 0x0072B630 File Offset: 0x00729830
		// (set) Token: 0x06001A6A RID: 6762 RVA: 0x0072B644 File Offset: 0x00729844
		public static int ClassDruid_ShapeshiftFormID1 { get; set; }

		// Token: 0x17000391 RID: 913
		// (get) Token: 0x06001A6B RID: 6763 RVA: 0x0072B658 File Offset: 0x00729858
		// (set) Token: 0x06001A6C RID: 6764 RVA: 0x0072B66C File Offset: 0x0072986C
		public static int ClassDruid_ShapeshiftFormID2 { get; set; }

		// Token: 0x17000392 RID: 914
		// (get) Token: 0x06001A6D RID: 6765 RVA: 0x0072B680 File Offset: 0x00729880
		// (set) Token: 0x06001A6E RID: 6766 RVA: 0x0072B694 File Offset: 0x00729894
		public static int Camera_Offset { get; set; }

		// Token: 0x17000393 RID: 915
		// (get) Token: 0x06001A6F RID: 6767 RVA: 0x0072B6A8 File Offset: 0x007298A8
		// (set) Token: 0x06001A70 RID: 6768 RVA: 0x0072B6BC File Offset: 0x007298BC
		public static int Camera_X { get; set; }

		// Token: 0x17000394 RID: 916
		// (get) Token: 0x06001A71 RID: 6769 RVA: 0x0072B6D0 File Offset: 0x007298D0
		// (set) Token: 0x06001A72 RID: 6770 RVA: 0x0072B6E4 File Offset: 0x007298E4
		public static int Camera_Y { get; set; }

		// Token: 0x17000395 RID: 917
		// (get) Token: 0x06001A73 RID: 6771 RVA: 0x0072B6F8 File Offset: 0x007298F8
		// (set) Token: 0x06001A74 RID: 6772 RVA: 0x0072B70C File Offset: 0x0072990C
		public static int Camera_Z { get; set; }

		// Token: 0x17000396 RID: 918
		// (get) Token: 0x06001A75 RID: 6773 RVA: 0x0072B720 File Offset: 0x00729920
		// (set) Token: 0x06001A76 RID: 6774 RVA: 0x0072B734 File Offset: 0x00729934
		public static int Camera_Matrix { get; set; }

		// Token: 0x17000397 RID: 919
		// (get) Token: 0x06001A77 RID: 6775 RVA: 0x0072B748 File Offset: 0x00729948
		// (set) Token: 0x06001A78 RID: 6776 RVA: 0x0072B75C File Offset: 0x0072995C
		public static int Camera_Fov { get; set; }

		// Token: 0x17000398 RID: 920
		// (get) Token: 0x06001A79 RID: 6777 RVA: 0x0072B770 File Offset: 0x00729970
		// (set) Token: 0x06001A7A RID: 6778 RVA: 0x0072B784 File Offset: 0x00729984
		public static int Chat_FirstMessage { get; set; }

		// Token: 0x17000399 RID: 921
		// (get) Token: 0x06001A7B RID: 6779 RVA: 0x0072B798 File Offset: 0x00729998
		// (set) Token: 0x06001A7C RID: 6780 RVA: 0x0072B7AC File Offset: 0x007299AC
		public static int Chat_FirstName { get; set; }

		// Token: 0x1700039A RID: 922
		// (get) Token: 0x06001A7D RID: 6781 RVA: 0x0072B7C0 File Offset: 0x007299C0
		// (set) Token: 0x06001A7E RID: 6782 RVA: 0x0072B7D4 File Offset: 0x007299D4
		public static int Chat_FirstChannelName { get; set; }

		// Token: 0x1700039B RID: 923
		// (get) Token: 0x06001A7F RID: 6783 RVA: 0x0072B7E8 File Offset: 0x007299E8
		// (set) Token: 0x06001A80 RID: 6784 RVA: 0x0072B7FC File Offset: 0x007299FC
		public static int Chat_Next { get; set; }

		// Token: 0x1700039C RID: 924
		// (get) Token: 0x06001A81 RID: 6785 RVA: 0x0072B810 File Offset: 0x00729A10
		// (set) Token: 0x06001A82 RID: 6786 RVA: 0x0072B824 File Offset: 0x00729A24
		public static int Professions_SkillLine { get; set; }

		// Token: 0x1700039D RID: 925
		// (get) Token: 0x06001A83 RID: 6787 RVA: 0x0072B838 File Offset: 0x00729A38
		// (set) Token: 0x06001A84 RID: 6788 RVA: 0x0072B84C File Offset: 0x00729A4C
		public static int Professions_ID { get; set; }

		// Token: 0x1700039E RID: 926
		// (get) Token: 0x06001A85 RID: 6789 RVA: 0x0072B860 File Offset: 0x00729A60
		// (set) Token: 0x06001A86 RID: 6790 RVA: 0x0072B874 File Offset: 0x00729A74
		public static int Professions_Rank { get; set; }

		// Token: 0x1700039F RID: 927
		// (get) Token: 0x06001A87 RID: 6791 RVA: 0x0072B888 File Offset: 0x00729A88
		// (set) Token: 0x06001A88 RID: 6792 RVA: 0x0072B89C File Offset: 0x00729A9C
		public static int Professions_MaxRank { get; set; }

		// Token: 0x170003A0 RID: 928
		// (get) Token: 0x06001A89 RID: 6793 RVA: 0x0072B8B0 File Offset: 0x00729AB0
		// (set) Token: 0x06001A8A RID: 6794 RVA: 0x0072B8C4 File Offset: 0x00729AC4
		public static int Frames_Base { get; set; }

		// Token: 0x170003A1 RID: 929
		// (get) Token: 0x06001A8B RID: 6795 RVA: 0x0072B8D8 File Offset: 0x00729AD8
		// (set) Token: 0x06001A8C RID: 6796 RVA: 0x0072B8EC File Offset: 0x00729AEC
		public static int Frames_BaseNext { get; set; }

		// Token: 0x170003A2 RID: 930
		// (get) Token: 0x06001A8D RID: 6797 RVA: 0x0072B900 File Offset: 0x00729B00
		// (set) Token: 0x06001A8E RID: 6798 RVA: 0x0072B914 File Offset: 0x00729B14
		public static int Frames_Frame { get; set; }

		// Token: 0x170003A3 RID: 931
		// (get) Token: 0x06001A8F RID: 6799 RVA: 0x0072B928 File Offset: 0x00729B28
		// (set) Token: 0x06001A90 RID: 6800 RVA: 0x0072B93C File Offset: 0x00729B3C
		public static int Frames_FrameNext { get; set; }

		// Token: 0x170003A4 RID: 932
		// (get) Token: 0x06001A91 RID: 6801 RVA: 0x0072B950 File Offset: 0x00729B50
		// (set) Token: 0x06001A92 RID: 6802 RVA: 0x0072B964 File Offset: 0x00729B64
		public static int Frames_Visible { get; set; }

		// Token: 0x170003A5 RID: 933
		// (get) Token: 0x06001A93 RID: 6803 RVA: 0x0072B978 File Offset: 0x00729B78
		// (set) Token: 0x06001A94 RID: 6804 RVA: 0x0072B98C File Offset: 0x00729B8C
		public static int Frames_GetText { get; set; }

		// Token: 0x170003A6 RID: 934
		// (get) Token: 0x06001A95 RID: 6805 RVA: 0x0072B9A0 File Offset: 0x00729BA0
		// (set) Token: 0x06001A96 RID: 6806 RVA: 0x0072B9B4 File Offset: 0x00729BB4
		public static int ChildFrames_Base { get; set; }

		// Token: 0x170003A7 RID: 935
		// (get) Token: 0x06001A97 RID: 6807 RVA: 0x0072B9C8 File Offset: 0x00729BC8
		// (set) Token: 0x06001A98 RID: 6808 RVA: 0x0072B9DC File Offset: 0x00729BDC
		public static int ChildFrames_Frame { get; set; }

		// Token: 0x170003A8 RID: 936
		// (get) Token: 0x06001A99 RID: 6809 RVA: 0x0072B9F0 File Offset: 0x00729BF0
		// (set) Token: 0x06001A9A RID: 6810 RVA: 0x0072BA04 File Offset: 0x00729C04
		public static int ChildFrames_BaseNext { get; set; }

		// Token: 0x170003A9 RID: 937
		// (get) Token: 0x06001A9B RID: 6811 RVA: 0x0072BA18 File Offset: 0x00729C18
		// (set) Token: 0x06001A9C RID: 6812 RVA: 0x0072BA2C File Offset: 0x00729C2C
		public static int ChildFrames_FrameNext { get; set; }

		// Token: 0x170003AA RID: 938
		// (get) Token: 0x06001A9D RID: 6813 RVA: 0x0072BA40 File Offset: 0x00729C40
		// (set) Token: 0x06001A9E RID: 6814 RVA: 0x0072BA54 File Offset: 0x00729C54
		public static int Spellbook_Spell { get; set; }

		// Token: 0x170003AB RID: 939
		// (get) Token: 0x06001A9F RID: 6815 RVA: 0x0072BA68 File Offset: 0x00729C68
		// (set) Token: 0x06001AA0 RID: 6816 RVA: 0x0072BA7C File Offset: 0x00729C7C
		public static int Spellbook_SpellID { get; set; }

		// Token: 0x170003AC RID: 940
		// (get) Token: 0x06001AA1 RID: 6817 RVA: 0x0072BA90 File Offset: 0x00729C90
		// (set) Token: 0x06001AA2 RID: 6818 RVA: 0x0072BAA4 File Offset: 0x00729CA4
		public static int Spellbook_RequiredLevel { get; set; }
	}
}
